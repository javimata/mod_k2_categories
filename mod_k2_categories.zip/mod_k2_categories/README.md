# mod_k2_categories
Select some categories to display it
